create function get_passanger(id integer) returns TABLE(pid integer, fname character varying, lname character varying, str character varying, town character varying, zip character varying)
  language plpgsql
as
$$
begin
  return query
    select * from passangers where passanger_id = id;
  end;
$$;

alter function get_passanger(integer) owner to postgres;

