create function single_trip_dest(a_station character varying, d_station character varying, want_days character varying) returns TABLE(routeid character varying, dist integer)
  language plpgsql
as
$$
declare
    di integer;
  begin
    drop table if exists dt, rid_days, arri, dest, r1, r2;
    create temp table dt as
      (select train_schedule.route_id from train_schedule where day_of_week = want_days);
    create temp table rid_days as
      (select r.route_id, r.station_id, r.station_num, r.station_status from routes_and_station_status as r inner join dt on r.route_id = dt.route_id);
    delete from rid_days where station_status = false;
    create temp table arri as
      (select rid_days.route_id, rid_days.station_num as sorder1 from rid_days where station_id = a_station);
    create temp table dest as
      (select rid_days.route_id, rid_days.station_num as sorder2 from rid_days where station_id = d_station);
    create temp table r1 as
      (select arri.route_id from (arri inner join dest on arri.route_id = dest.route_id and arri.sorder1 < dest.sorder2));
    create temp table r2(route_id varchar(10), dist integer);

    while (select count(r1.route_id) from r1) <> 0 loop
      drop table if exists tt1, j1;
      create temp table tt1 as
        (select * from get_seq((select min(r1.route_id) from r1), a_station, d_station));
      create temp table j1 as
        (select * from tt1 as t join rail_distances as d on (t.curst = d.station_prev and t.targst = d.station_next));
      insert into r2(route_id, dist) values ((select min(r1.route_id) from r1), (select sum(station_distances) from j1));
      delete from r1 where r1.route_id = (select min(r1.route_id) from r1);
    end loop;

    return query
      select * from r2;
  end;
$$;

alter function single_trip_dest(varchar, varchar, varchar) owner to postgres;

