create function never_pass(want_staton character varying) returns TABLE(np_train character varying)
  language plpgsql
as
$$
begin
  --select route_id from routes_and_station_status where station_status = false and station_id = want_staton;
  return query
    select train_id from train_schedule where route_id = (select route_id from routes_and_station_status where station_status = false and station_id = want_staton) group by train_id;

  end;
$$;

alter function never_pass(varchar) owner to postgres;

