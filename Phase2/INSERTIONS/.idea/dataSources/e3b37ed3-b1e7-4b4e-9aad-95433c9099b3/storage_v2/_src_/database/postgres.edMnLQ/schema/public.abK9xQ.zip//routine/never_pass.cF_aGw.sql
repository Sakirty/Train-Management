create function never_pass(want_staton character varying) returns TABLE(np_train character varying)
  language plpgsql
as
$$
begin
  drop table if exists t1,t2,t3;
  create temp table t1 as
    (select * from routes_and_station_status where station_id = want_staton);
  delete from t1 where station_status = false;
  create temp table t2 as
    (select t1.route_id from t1 group by route_id);
  create temp table t3 as
    (select * from train_schedule);
  delete from t3 where t3.route_id not in (select t2.route_id from t2);



  return query
    select distinct train_id from t3;
  end;
$$;

alter function never_pass(varchar) owner to postgres;

