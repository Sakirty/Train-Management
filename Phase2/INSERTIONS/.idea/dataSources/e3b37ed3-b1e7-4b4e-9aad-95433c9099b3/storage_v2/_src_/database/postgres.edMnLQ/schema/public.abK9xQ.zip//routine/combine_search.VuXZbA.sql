create function combine_search(want_days character varying, a_station character varying, d_station character varying) returns TABLE(route_1 character varying, route_2 character varying, trans_station character varying)
  language plpgsql
as
$$
BEGIN
  drop table if exists dt, rid_day,arri, arri_order, arri_routes, dest, dest_order, dest_routes, tablea, tableb, tablec, comb_table;
  create temp table dt as
    (select train_schedule.route_id, train_schedule.time_route from train_schedule where day_of_week = want_days);
  create temp table rid_day as
    (select r.route_id, r.station_id, r.station_num, r.station_status,dt.time_route from routes_and_station_status as r inner join dt on r.route_id = dt.route_id);
  delete from rid_day where station_status = false;
  create temp table arri_routes as
     (select rid_day.route_id, rid_day.time_route from rid_day where station_id = a_station);
  create temp table arri as
      (select rid_day.route_id, rid_day.station_id, rid_day.station_num as sorder1 from (rid_day inner join arri_routes on (rid_day.route_id = arri_routes.route_id and rid_day.time_route = arri_routes.time_route)));
  create temp table arri_order as
      (select arri.route_id, arri.sorder1 from arri where arri.station_id = a_station);
  create temp table dest_routes as
  (select rid_day.route_id,rid_day.time_route from rid_day where station_id = d_station);
  create temp table dest as
    (select rid_day.route_id, rid_day.station_id, rid_day.station_num as sorder2 from (rid_day inner join dest_routes on (rid_day.route_id = dest_routes.route_id and rid_day.time_route = dest_routes.time_route)));
  create temp table dest_order as
    (select dest.route_id, dest.sorder2 from dest where dest.station_id = d_station);
  create temp table comb_table as
    (select arri.route_id as arid, dest.route_id as drid, arri.station_id as asid, dest.route_id as dsid, arri.sorder1 as aorder, dest.sorder2 as dorder from arri cross join dest);
  delete from comb_table where arid = drid;
  delete from comb_table where (asid = a_station or dsid = d_station or asid = d_station or dsid = a_station);
  create temp table tablea as
    (select arid, drid, asid,dsid, dorder from (comb_table inner join arri_order on (comb_table.aorder > arri_order.sorder1 and comb_table.arid = arri_order.route_id)));
  create temp table tableb as
    (select arid, drid,asid,dsid from (tablea inner join dest_order on (tablea.dorder < dest_order.sorder2 and tablea.drid = dest_order.route_id)));
  create temp table tablec as
    (select distinct arid, drid, asid, dsid from tableb);
  return query
    select arid, drid, asid from tablec where asid = dsid;

  end;
$$;

alter function combine_search(varchar, varchar, varchar) owner to postgres;

