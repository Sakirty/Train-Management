create function stops_min(a_station character varying, d_station character varying, want_days character varying) returns TABLE(rid character varying, stop_num integer)
  language plpgsql
as
$$
begin
    drop table if exists dt, rid_days, r1,r2,arri,dest;
    create temp table dt as
      (select train_schedule.route_id from train_schedule where day_of_week = want_days);
    create table rid_days as
      (select r.route_id, r.station_id, r.station_num, r.station_status from routes_and_station_status as r inner join dt on r.route_id = dt.route_id);
    delete from rid_days where station_status = false;
    create temp table arri as
      (select rid_days.route_id, rid_days.station_num as sorder1 from rid_days where station_id = a_station);
    create temp table dest as
      (select rid_days.route_id, rid_days.station_num as sorder2 from rid_days where station_id = d_station);
    create temp table r1 as
      (select arri.route_id from (arri inner join dest on arri.route_id = dest.route_id));

    create temp table r2 (rids varchar(10), numstop integer);
    while (select count(r1.route_id) from r1)<>0 loop
      insert into r2(rids, numstop) values ((select min(r1.route_id) from r1), (stops_amount((select min(r1.route_id) from r1), a_station, d_station)));
      delete from r1 where r1.route_id = (select min(r1.route_id) from r1);
    end loop;

    return query
      select * from r2;
  end;
$$;

alter function stops_min(varchar, varchar, varchar) owner to postgres;

