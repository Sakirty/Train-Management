create function pass_multi() returns TABLE(multi_route character varying)
  language plpgsql
as
$$
begin
    drop table if exists t1, t2;
    create temp table t1 as (select distinct route_id, rail_id from routes_and_station_status left join rail_stations
  on routes_and_station_status.station_id = rail_stations.station_id);
    create temp table t2 as (select route_id, count(route_id) from t1 group by route_id);
    delete from t2 where count = 1;
    return query
      select route_id from t2;
  end;
$$;

alter function pass_multi() owner to postgres;

