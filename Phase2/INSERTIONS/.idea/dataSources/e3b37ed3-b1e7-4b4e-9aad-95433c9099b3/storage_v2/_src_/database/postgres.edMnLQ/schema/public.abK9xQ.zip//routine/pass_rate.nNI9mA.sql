create function pass_rate(percentage double precision) returns TABLE(p_route character varying)
  language plpgsql
as
$$
begin
  return query
    select route_id from routes where stop_rate >= percentage group by route_id;
  end;
$$;

alter function pass_rate(double precision) owner to postgres;

