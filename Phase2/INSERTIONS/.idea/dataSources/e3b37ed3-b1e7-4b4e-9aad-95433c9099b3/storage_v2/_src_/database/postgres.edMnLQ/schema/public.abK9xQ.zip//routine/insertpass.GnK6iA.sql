create function insertpass(first_name character varying, last_name character varying, street1 character varying, town1 character varying, zip1 character varying) returns void
  language plpgsql
as
$$
declare
  pass_id int;
  begin
    select MAX(passanger_id)+1 into pass_id from passangers;
    INSERT INTO passangers(passanger_id, f_name, l_name, street, town, zip)
    VALUES(pass_id, first_name, last_name, street1, town1, zip1);
  end;
$$;

alter function insertpass(varchar, varchar, varchar, varchar, varchar) owner to postgres;

