create function available_seats() returns TABLE(train_id character varying)
  language plpgsql
as
$$
BEGIN
  return query
    select seats.train_id from seats where open_status = true;
  end;
$$;

alter function available_seats() owner to postgres;

