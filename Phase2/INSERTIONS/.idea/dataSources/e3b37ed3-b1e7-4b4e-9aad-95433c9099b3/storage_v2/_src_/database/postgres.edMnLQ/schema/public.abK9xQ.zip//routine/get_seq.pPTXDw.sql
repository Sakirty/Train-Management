create function get_seq(routeid character varying, arri_id character varying, dest_id character varying) returns TABLE(curst character varying, targst character varying)
  language plpgsql
as
$$
declare
    max1 varchar(10);
    max2 varchar(10);
  begin
    drop table if exists temp_table, temp_table2, t1, t2;
    create temp table temp_table as (select station_id, station_num from routes_and_station_status where route_id = routeid);
    create temp table temp_table2 as  (select station_id, station_num from temp_table where (station_num between (select station_num from temp_table where station_id = arri_id) and (select station_num from temp_table where station_id = dest_id)));
    create temp table t1 as (select * from temp_table2);
    create temp table t2 as (select * from temp_table2);
    delete from t1 where station_id = arri_id;
    delete from t2 where station_id = dest_id;
    select max(station_num) into max1 from t1;
    select max(station_num) into max2 from t2;
    if max1 > max2 then
      return query
        select t2.station_id, t1.station_id from (t1 join t2 on t1.station_num = t2.station_num + 1);
    else
      return query
        select t2.station_id, t2.station_id from (t1 join t2 on t1.station_num = t2.station_num - 1);
    end if;
  end;
$$;

alter function get_seq(varchar, varchar, varchar) owner to postgres;

