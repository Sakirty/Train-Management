create function display_route(want_route character varying) returns TABLE(day_get character varying, time_get character varying, train_get character varying)
  language plpgsql
as
$$
begin
    return query
      select day_of_week, time_route, train_id from train_schedule where route_id = want_route;
  end;
$$;

alter function display_route(varchar) owner to postgres;

