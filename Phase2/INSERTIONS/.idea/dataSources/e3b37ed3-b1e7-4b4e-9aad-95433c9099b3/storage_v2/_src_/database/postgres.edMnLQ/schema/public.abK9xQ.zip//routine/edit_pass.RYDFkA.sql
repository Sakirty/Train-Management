create function edit_pass() returns trigger
  language plpgsql
as
$$
declare
    temp_id int;
  begin
		select passanger_id into temp_id from passangers where passanger_id = new.passanger_id;
		if temp_id IS NULL then
   		RAISE EXCEPTION 'THAT ID DOES NOT EXIST!';
		end if;
		return new;
	end;
$$;

alter function edit_pass() owner to postgres;

