create function available_seats(route character varying) returns TABLE(train_id character varying)
  language plpgsql
as
$$
BEGIN
    drop table if exists t1;
    create temp table t1 as
      (select distinct train_id from train_schedule where route_id = route);
    create temp table t2 as
      (select * from seats where train_id in (select train_id from t1));
  return query
    select t2.train_id from t2 where open_status = true;
  end;
$$;

alter function available_seats(varchar) owner to postgres;

