create function all_trian_pass_through() returns TABLE(null_station character varying)
  language plpgsql
as
$$
begin
    drop table if exists t1, t2, t3;
    create temp table t1 as (select route_id from train_schedule group by route_id);
    create temp table t2 as (select * from routes_and_station_status);
    delete from t2 where route_id not in (select route_id from t1);
    delete from t2 where station_status = true;
    create temp table t3 as (select station_id, count(station_id) from t2 group by station_id);
    delete from t3 where count < 350;--(select count(route_id) from t2);
    return query
      select station_id from t3;
  end;
$$;

alter function all_trian_pass_through() owner to postgres;

