create function single_search(want_days character varying, a_station character varying, d_station character varying) returns TABLE(route_id character varying)
  language plpgsql
as
$$
BEGIN
  drop table if exists selected_route, arri_table, dest_table;
  create temp table dt as
    (select train_schedule.route_id, train_schedule.time_route from train_schedule where day_of_week = want_days);
  create temp table rid_day as
    (select r.route_id, r.station_id, r.station_num, r.station_status,dt.time_route from routes_and_station_status as r inner join dt on r.route_id = dt.route_id);
  delete from rid_day where station_status = false;
  create temp table arri as
    (select rid_day.route_id, rid_day.time_route, rid_day.station_num as sorder1 from rid_day where station_id = a_station);
  create temp table dest as
    (select rid_day.route_id, rid_day.time_route, rid_day.station_num as sorder2 from rid_day where station_id = d_station);

  return query
    select arri.route_id from (arri inner join dest on (arri.route_id = dest.route_id and arri.time_route = dest.time_route) and arri.sorder1 < dest.sorder2);
  end;
$$;

alter function single_search(varchar, varchar, varchar) owner to postgres;

