create function sta_amount(rid character varying, a_station character varying, d_station character varying) returns integer
  language plpgsql
as
$$
declare
    inoo integer;
  begin
    drop table if exists tmp1, tmp2;
    create temp table tmp1 as
      (select station_id, station_num from routes_and_station_status where route_id = rid);
    create temp table tmp2 as
      (select tmp1.station_id, tmp1.station_num from tmp1 where (tmp1.station_num between (select station_num from tmp1 where tmp1.station_id = a_station) and (select station_num from tmp1 where tmp1.station_id = d_station)));
    inoo := (select count(*) from tmp2);
    return inoo;
  end;
$$;

alter function sta_amount(varchar, varchar, varchar) owner to postgres;

