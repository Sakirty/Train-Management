create function same_stations(routeid character varying) returns TABLE(rid character varying)
  language plpgsql
as
$$
begin
    drop table tr1, tr2, tr3, tr4;
  create temp table tr1 as
      (select * from routes_and_station_status where route_id <> routeid);
  --select * from tr1;
  create temp table tr2 as
      (select route_id, count(station_id) from tr1 group by route_id);
  --select * from tr2;
  delete from tr2 where tr2.count <> (select count(station_id) from routes_and_station_status where route_id = routeid);
   delete from tr1 where tr1.route_id not in (select tr2.route_id from tr2);

  create temp table tr3 as
      (select * from routes_and_station_status where route_id = routeid);
  --select * from tr3;

  delete from tr1 where station_id not in (select station_id from tr3);

  create temp table tr4 as
      (select route_id, count(station_id) from tr1 group by route_id);
  --select * from tr4;

  delete from tr4 where count <> (select count(station_id) from routes_and_station_status where route_id = routeid);
  delete from tr1 where route_id not in (select route_id from tr4);

  return query
    select route_id from tr4;
  end;
$$;

alter function same_stations(varchar) owner to postgres;

